@extends('layaut')
@section('content')
<table class="table">
  <thead class="table table-info">
   
  </thead>
  <tbody class="table table-premium">
   </tbody>
</table>
@endsection()