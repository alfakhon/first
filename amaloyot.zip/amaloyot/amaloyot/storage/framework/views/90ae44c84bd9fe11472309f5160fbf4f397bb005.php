
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cat.update',['cat'=>$cats->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <input type="text" name="cat" id="" value="<?php echo e($cats->cat); ?>" class="form-control"><br>
    <button type="submit" name="s" class="btn btn-primary">send</button>
    <a href="<?php echo e(route('cat.index')); ?>" class="btn btn-dark">back</a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaut', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\amaloyot\resources\views/cat/edit.blade.php ENDPATH**/ ?>