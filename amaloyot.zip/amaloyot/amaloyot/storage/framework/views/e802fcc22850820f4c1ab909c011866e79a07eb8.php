
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($error); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
</div>
<?php endif; ?>
<form action="<?php echo e(route('minusstore')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?>
    <input type="hidden" name="cat_id" value="<?php echo e($color->types->cats->id); ?>">
    <input type="hidden" name="type_id" value="<?php echo e($color->types->id); ?>">
    <input type="hidden" name="color_id" value="<?php echo e($color->id); ?>">

    <input type="number" name="amount"  id="" placeholder="amount" class="form-control">
    <input type="number" name="r_soni"  id="" class="form-control" placeholder="rulon soni">
    <input type="text" name="desc"  id="" class="form-control">
    <input type="hidden" name="status" value="0">
    <input type="date" name="vaqt" class="form-control" id="">
    <input type="submit" class="btn btn-info">
    <a href="<?php echo e(route('income.index')); ?>" class="btn btn-info">back</a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaut', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\amaloyot\resources\views/income/minus.blade.php ENDPATH**/ ?>