<?php $__env->startSection('content'); ?>
<table class="table">
  <thead class="table table-info">
   
  </thead>
  <tbody class="table table-premium">
   </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaut', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\amaloyot\resources\views/index.blade.php ENDPATH**/ ?>