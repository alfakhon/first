
<?php $__env->startSection('content'); ?>
<table class="table">
  <thead class="">
    <tr>
        <th>
                No
        </th>
        <th>
                Amount
        </th>
        <th>
                Rulon
        </th>
       
        <th>
            Status
        </th>
        <th>
           Deskription
        </th>
        <th>
            edit/trash
        </th>
        
    </tr>
  </thead>
  <tbody class="table table-premium">
        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($color->status==1): ?>

    <tr class="table table-info">
            <td>
                <?php echo e($loop->iteration); ?>

            </td>
            <td>
                <?php echo e($color->amount); ?>

            </td>
            <td>
                <?php echo e($color->r_soni); ?>

            </td>
            <td>
                <?php if($color->status==1): ?>
                qoshildi
                <?php else: ?>
                olindi
                <?php endif; ?>

            </td>
            <td><?php echo e($color->desc); ?></td>
            
            
             <td>
                <a href="<?php echo e(route('income.edit',['income'=>$color->id])); ?>">
                    <i class="fas fa-2x fa-edit">
    
                    </i>
                </a>
                <form action="<?php echo e(route('delincome')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="color_id" value="<?php echo e($color->color_id); ?>">
                    <input type="hidden" name="id" value="<?php echo e($color->id); ?>">
                    <input type="hidden" name="status" value="<?php echo e($color->status); ?>">
                    <input type="submit" class="delsub" style="display: none;">

                </form>
                
                <a href="<?php echo e($color->id); ?>" class="del">
                    <i class="fas fa-2x fa-trash">
    
                    </i>
                </a>
            </td> 
    </tr>
    <?php else: ?>
    <tr class="table table-danger">
        <td>
            <?php echo e($loop->iteration); ?>

        </td>
        <td>
            <?php echo e($color->amount); ?>

        </td>
        <td>
            <?php echo e($color->r_soni); ?>

        </td>
        <td>
            <?php if($color->status==1): ?>
            qoshildi
            <?php else: ?>
            olindi
            <?php endif; ?>

        </td>
        <td><?php echo e($color->desc); ?></td>
        
        
        <td>
            <a href="<?php echo e(route('income.edit',['income'=>$color->id])); ?>">
                <i class="fas fa-2x fa-edit">

                </i>
            </a>
            <form action="<?php echo e(route('delincome')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="color_id" value="<?php echo e($color->color_id); ?>">
                <input type="hidden" name="id" value="<?php echo e($color->id); ?>">
                <input type="hidden" name="status" value="<?php echo e($color->status); ?>">
                <input type="submit" class="delsub" style="display: none;">

            </form>
            
            <a href="<?php echo e($color->id); ?>" class="del">
                <i class="fas fa-2x fa-trash">

                </i>
            </a>
        </td> 
</tr>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </tbody>
</table>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<script>
    $(function () {
      $('.del').click(function(e) {
          e.preventDefault();
          var id=$(this).attr('href');
          var qiy=confirm('Ochirilsinmi');
          if (qiy==true) {
              $('.delsub').click();
          }
      })
    })
</script>
<?php echo $__env->make('layaut', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\amaloyot\resources\views/income/full.blade.php ENDPATH**/ ?>